package com.example.menu_inferior

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
