import 'package:flutter/material.dart';

class SettingsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text("Hola, Configuración", style: TextStyle(fontSize: 24)),
    );
  }
}
