package com.example.menu_lateral

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
