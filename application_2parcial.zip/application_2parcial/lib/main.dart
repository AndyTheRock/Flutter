import 'package:flutter/material.dart';

//1
class Agenda {
  String nombre;
  String control;

  Agenda({required this.nombre, required this.control});
}


//2
void main() {
  runApp(AgendaApp());
}

class AgendaApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: AgendaScreen(),
    );
  }
}

class AgendaScreen extends StatefulWidget {
  @override
  _AgendaScreenState createState() => _AgendaScreenState();
}

class _AgendaScreenState extends State<AgendaScreen> {
  final TextEditingController _nombreController = TextEditingController();
  final TextEditingController _controlController = TextEditingController();
  List<Agenda> _contactos = [];
  String _contactCount = "0";

  // Función para agregar contactos
  void _agregarContacto() {
    if (_nombreController.text.isNotEmpty && _controlController.text.isNotEmpty) {
      setState(() {
        _contactos.add(Agenda(nombre: _nombreController.text, control: _controlController.text));
        _contactCount = _contactos.length.toString();
        _nombreController.clear();
        _controlController.clear();
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Por favor, completa ambos campos.")));
    }
  }

  // Navegar a la pantalla de listado
  void _verAgenda() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ContactListScreen(contactos: _contactos)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Agenda')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text('Agenda', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            TextField(
              controller: _nombreController,
              decoration: InputDecoration(labelText: 'Nombre'),
            ),
            TextField(
              controller: _controlController,
              decoration: InputDecoration(labelText: 'No. Control'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: _agregarContacto,
              child: Text('Agregar'),
            ),
            ElevatedButton(
              onPressed: _verAgenda,
              child: Text('Ver agenda'),
            ),
            SizedBox(height: 20),
            Text('Contactos agregados: $_contactCount'),
          ],
        ),
      ),
    );
  }
}



//3 

class ContactListScreen extends StatelessWidget {
  final List<Agenda> contactos;

  ContactListScreen({required this.contactos});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Listado de contactos')),
      body: ListView.builder(
        itemCount: contactos.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(contactos[index].nombre),
            subtitle: Text("No. Control: ${contactos[index].control}"),
          );
        },
      ),
    );
  }
}
