package com.example.application_2parcial

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
